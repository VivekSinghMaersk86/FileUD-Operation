package com.maersk.Transferfile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TransferfileApplication {

	public static void main(String[] args) {
		SpringApplication.run(TransferfileApplication.class, args);
	}

}
