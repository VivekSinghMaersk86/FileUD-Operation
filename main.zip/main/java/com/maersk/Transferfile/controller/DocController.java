package com.maersk.Transferfile.controller;

import com.maersk.Transferfile.model.Doc;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.io.File;

@Controller
public class DocController {

    Doc docOP=new Doc();

    @GetMapping("/doc")
    public String get(Model model) {
        System.out.println("inside Doc");
        return "doc";
    }

     @PostMapping("/uploadFiles")
      public String uploadMultipleFiles(@RequestParam("files") MultipartFile file) {
       System.out.println("inside upload files");
       String fileName = file.getOriginalFilename();
        try {
           file.transferTo(new File("C:\\_Project\\PFT\\TempCustomFile\\44annex\\SCMTR\\Outbound\\" + fileName));
       }catch(Exception e){
           return  "uploadFile Directory Exception";
       }
       return "redirect:/doc";
     }

   // @PostMapping("/uploadFiles" ; params = "graphic")
   @RequestMapping(value = "/uploadFiles", method = {RequestMethod.POST}, params = "graphic")
    public String graphicUploadFiles(@RequestParam("files") MultipartFile file) {
        System.out.println("inside graphicUpload files");
        String fileName = file.getOriginalFilename();
        try {
            file.transferTo(new File("C:\\_Project\\PFT\\TempCustomFile\\45main\\SCMTR\\OutBound\\" + fileName));
        }catch(Exception e){
            return  "uploadFile graphic Directory Exception";
        }
        return "redirect:/doc";
    }

    @RequestMapping(value = "/uploadFiles", method = {RequestMethod.POST}, params = "TestOrg")
    public String TestOrgUploadFiles(@RequestParam("files") MultipartFile file) {
        System.out.println("inside TestOrg files");
        String fileName = file.getOriginalFilename();
        try {
            file.transferTo(new File("C:\\_Project\\PFT\\TempCustomFile\\TestOrg\\" + fileName));
        }catch(Exception e){
            return  "uploadFile TestOrg Directory Exception";
        }
        return "redirect:/doc";
    }

}
