package com.maersk.Transferfile.service;


import com.maersk.Transferfile.model.User;

public interface UserService {
    void save(User user);

    User findByUsername(String username);
}
