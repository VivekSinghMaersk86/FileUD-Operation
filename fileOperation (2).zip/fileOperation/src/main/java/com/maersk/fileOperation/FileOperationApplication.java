package com.maersk.fileOperation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FileOperationApplication {

	public static void main(String[] args) {
		SpringApplication.run(FileOperationApplication.class, args);
	}

}
