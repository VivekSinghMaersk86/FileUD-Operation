package com.maersk.Transferfile.controller;

import com.maersk.Transferfile.model.FileModel;
import com.maersk.Transferfile.util.DirAccessUtil;
import com.maersk.Transferfile.util.ZipUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Controller
public class DirAccessController {

    DirAccessUtil dirAccessUtil = new DirAccessUtil();

    //ArrayList<String> filepathList =new ArrayList<String>();
    int count = 0;
    private String folderPath = "C:/Users/VKS046/Downloads/";
    String folderPath1 = "C:/Users/VKS046/Downloads/OutputModule";
        String folderPath2 = "C:/Users/VKS046/Downloads/InputModule";
    String folderPath3 = "C:/Users/VKS046/Downloads/SCMTR";
    String folderPath4 = "C:/Users/VKS046/Downloads/sftpLogs";
    String folderPath31 = "C:/Users/VKS046/Downloads/SCMTR/Process";
    String folderPath32 = "C:/Users/VKS046/Downloads/SCMTR/Inbound";
    String folderPath33 = "C:/Users/VKS046/Downloads/SCMTR/Outbound";

    //filepathList.add(folderPath1);

    @RequestMapping({"/showFiles"})
    public String showFiles(Model model) {

        System.out.println("inside showfiles");
        File folder = new File(folderPath);

        File[] listOfFiles = folder.listFiles();

        List<FileModel> list = new ArrayList<>();

        dirAccessUtil.addFilesNameToList(listOfFiles, list);
        model.addAttribute("files", list);
        return "showFiles";
    }

    @RequestMapping({"/outputModuleDirFile"})
    public String showOutputModuleDirFile(Model model1) {

        File folder1 = new File(folderPath1);

        File[] listOfFiles = folder1.listFiles();

        List<FileModel> list = new ArrayList<>();

        for (int i = 0; i < listOfFiles.length; i++) {
            FileModel FileModelObj = new FileModel();
            FileModelObj.FileName = listOfFiles[i].getName();
            long millisec = listOfFiles[i].lastModified();
            Date dt = new Date(millisec);
            FileModelObj.FileDate = dt;
            list.add(FileModelObj);
        }
        model1.addAttribute("files", list);
        return "outputModuleDirFile";
    }

    @RequestMapping({"/inputModuleDirFile"})
    public String showinputModuleDirFile(Model model2) {

        File folder2 = new File(folderPath2);

        File[] listOfFiles = folder2.listFiles();

        List<FileModel> list = new ArrayList<>();

        for (int i = 0; i < listOfFiles.length; i++) {
            FileModel FileModelObj = new FileModel();
            FileModelObj.FileName = listOfFiles[i].getName();
            long millisec = listOfFiles[i].lastModified();
            Date dt = new Date(millisec);
            FileModelObj.FileDate = dt;
            list.add(FileModelObj);
        }
        model2.addAttribute("files", list);
        return "inputModuleDirFile";
    }

    @RequestMapping({"/scmtrDirFile"})
    public String showScmtrDirFile(Model model3) {

        File folder3 = new File(folderPath3);

        File[] listOfFiles = folder3.listFiles();

        List<FileModel> list = new ArrayList<>();

        for (int i = 0; i < listOfFiles.length; i++) {
            FileModel FileModelObj = new FileModel();
            FileModelObj.FileName = listOfFiles[i].getName();
            long millisec = listOfFiles[i].lastModified();
            Date dt = new Date(millisec);
            FileModelObj.FileDate = dt;
            list.add(FileModelObj);
        }

        model3.addAttribute("files", list);
        return "scmtrDirFile";

    }

    @RequestMapping({"/sftpLogsDirFile"})
    public String showSftpLogsDirFile(Model model4) {

        File folder4 = new File(folderPath4);

        File[] listOfFiles = folder4.listFiles();

        List<FileModel> list = new ArrayList<>();

        for (int i = 0; i < listOfFiles.length; i++) {
            FileModel FileModelObj = new FileModel();
            FileModelObj.FileName = listOfFiles[i].getName();
            long millisec = listOfFiles[i].lastModified();
            Date dt = new Date(millisec);
            FileModelObj.FileDate = dt;
            list.add(FileModelObj);
        }

        model4.addAttribute("files", list);
        return "sftpLogsDirFile";

    }

    @GetMapping({"/{fileName}"})
    @ResponseBody
    public void show(@PathVariable("fileName") String fileName, HttpServletResponse response) {
        count++;
       List<String> directories = new ArrayList<>();
        List<String> folderNameList = new ArrayList<>();
        File f = new File(folderPath);

        File[] listOfFiles = f.listFiles();

        for (int i = 0; i < listOfFiles.length; i++) {

            if (listOfFiles[i].isFile()) {

                if (fileName.indexOf(".doc") > -1) response.setContentType("application/msword");
                if (fileName.indexOf(".docx") > -1) response.setContentType("application/msword");
                if (fileName.indexOf(".xls") > -1) response.setContentType("application/vnd.ms-excel");
                if (fileName.indexOf(".csv") > -1) response.setContentType("application/vnd.ms-excel");
                if (fileName.indexOf(".ppt") > -1) response.setContentType("application/ppt");
                if (fileName.indexOf(".pdf") > -1) response.setContentType("application/pdf");
                if (fileName.indexOf(".zip") > -1) response.setContentType("application/zip");

            }

            if (listOfFiles[i].isDirectory()) {
                directories.add(listOfFiles[i].getName());
            }
        }

        if(count == 1 ) {
            ZipUtils zipUtils = new ZipUtils();
            zipUtils.finalExecute(directories);
           }
        response.setHeader("Content-Disposition", "attachment; filename=" + fileName);
        response.setHeader("Content-Transfer-Encoding", "binary");

        if(count == 1 ) {
        try {
            BufferedOutputStream bos = new BufferedOutputStream(response.getOutputStream());

           FileInputStream fis = new FileInputStream(folderPath + fileName);
            int len;
            byte[] buf = new byte[1024];
            while ((len = fis.read(buf)) > 0) {
                bos.write(buf, 0, len);
            }
            bos.close();
            response.flushBuffer();
        } catch (IOException e) {
            e.printStackTrace();

        } }
    }

   @RequestMapping({"/outboundDirFile"})
    public String showOutBoundDirFile(Model model33) {

        File folder33 = new File(folderPath33);

        File[] listOfFiles33 = folder33.listFiles();

        List<FileModel> list = new ArrayList<>();

        for (int i = 0; i < listOfFiles33.length; i++) {
            FileModel FileModelObj = new FileModel();
            FileModelObj.FileName = listOfFiles33[i].getName();
            long millisec = listOfFiles33[i].lastModified();
            Date dt = new Date(millisec);
            FileModelObj.FileDate = dt;
            list.add(FileModelObj);
        }

        model33.addAttribute("files", list);
        return "outboundDirFile";
    }
    @RequestMapping({"/inboundDirFile"})
    public String showinBoundDirFile(Model model32) {

        File folder32 = new File(folderPath32);

        File[] listOfFiles32 = folder32.listFiles();

        List<FileModel> list = new ArrayList<>();

        for (int i = 0; i < listOfFiles32.length; i++) {
            FileModel FileModelObj = new FileModel();
            FileModelObj.FileName = listOfFiles32[i].getName();
            long millisec = listOfFiles32[i].lastModified();
            Date dt = new Date(millisec);
            FileModelObj.FileDate = dt;
            list.add(FileModelObj);
        }

        model32.addAttribute("files", list);
        return "inboundDirFile";
    }
    @RequestMapping({"/processDirFile"})
    public String showprocessDirFile(Model model31) {

        File folder31 = new File(folderPath31);

        File[] listOfFiles31 = folder31.listFiles();

        List<FileModel> list = new ArrayList<>();

        for (int i = 0; i < listOfFiles31.length; i++) {
            FileModel FileModelObj = new FileModel();
            FileModelObj.FileName = listOfFiles31[i].getName();
            long millisec = listOfFiles31[i].lastModified();
            Date dt = new Date(millisec);
            FileModelObj.FileDate = dt;
            list.add(FileModelObj);
        }

        model31.addAttribute("files", list);
        return "processDirFile";
    }

}


